//
//  main.swift
//  20180726
//
//  Created by KimYoungHoon on 2018. 7. 26..
//  Copyright © 2018년 GGULUE. All rights reserved.
//

import Foundation


//3으로 나누어지는 숫자 필터링 하기
var array : [Int] = [123, 452, 7413, 25, 302]
var newArray : [Int] = []
for item in array{
    if item%3 == 0{
        newArray.append(item)
    }
}

//sort, array 배열을 오름차순 및 내림차순으로 정렬하기

//reduce array 배열의 평균값 구하기

//map, array 2n+1이라는 수열의 초항부터 array[i]째 항까지의 합을 구하기
var newArray_2 : [Int] = []
func asdf(_ a: Int) -> Int {
    return a*a+(2*a)
}
for item in array{
    newArray_2.append(asdf(item))
}
